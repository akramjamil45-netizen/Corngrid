param(
 [Parameter(Mandatory=$true)][string]$TerminalDirectory,
 [Parameter(Mandatory=$true)][string]$RequestFile,
 [Parameter(Mandatory=$true)][string]$ResultFile,
 [ValidateRange(10,120)][int]$TimeoutSeconds=60
)
$ErrorActionPreference='Stop'
$directory=[IO.Path]::GetFullPath($TerminalDirectory);$terminal=Join-Path $directory 'terminal64.exe'
$request=Get-Content -LiteralPath $RequestFile -Raw | ConvertFrom-Json
if($request.requestId -notmatch '^[a-f0-9-]{36}$' -or @($request.urls).Count -lt 1 -or @($request.urls).Count -gt 20){throw 'Invalid WebRequest configuration request.'}
foreach($url in $request.urls){$uri=[Uri]$url;if(-not $uri.IsAbsoluteUri -or $uri.Scheme -notin @('https','http') -or $uri.UserInfo -or $uri.Fragment -or $url.Length -gt 512 -or $url -match '[\r\n\x00]'){throw 'Invalid WebRequest URL.'}}
$owners=@(Get-CimInstance Win32_Process -Filter "Name='terminal64.exe'" | Where-Object{$_.ExecutablePath -and [IO.Path]::GetFullPath($_.ExecutablePath) -ieq $terminal})
if($owners.Count -ne 1){throw 'WebRequest setup requires exactly one owned preflight terminal.'}
$ownedPid=[int]$owners[0].ProcessId
Add-Type @'
using System;using System.Text;using System.Runtime.InteropServices;using System.Collections.Generic;
public class CornGridWebRequest {
 public delegate bool EnumProc(IntPtr h,IntPtr p);
 [DllImport("user32.dll")]public static extern bool EnumWindows(EnumProc f,IntPtr p);
 [DllImport("user32.dll")]public static extern bool EnumChildWindows(IntPtr h,EnumProc f,IntPtr p);
 [DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]public static extern int GetWindowText(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]public static extern int GetClassName(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll")]public static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")]public static extern bool IsWindowEnabled(IntPtr h);
 [DllImport("user32.dll")]public static extern int GetDlgCtrlID(IntPtr h);
 [DllImport("user32.dll")]public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);
 [DllImport("user32.dll")]public static extern IntPtr GetMenu(IntPtr h);
 [DllImport("user32.dll")]public static extern IntPtr GetSubMenu(IntPtr h,int n);
 [DllImport("user32.dll")]public static extern int GetMenuItemCount(IntPtr h);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]public static extern int GetMenuString(IntPtr h,uint n,StringBuilder s,int c,uint f);
 [DllImport("user32.dll")]public static extern uint GetMenuItemID(IntPtr h,int n);
 [DllImport("user32.dll",EntryPoint="SendMessageTimeoutW")]static extern IntPtr SendPtr(IntPtr h,uint m,IntPtr w,IntPtr l,uint flags,uint timeout,out IntPtr r);
 [DllImport("user32.dll",CharSet=CharSet.Unicode,EntryPoint="SendMessageTimeoutW")]static extern IntPtr SendText(IntPtr h,uint m,IntPtr w,string l,uint flags,uint timeout,out IntPtr r);
 [DllImport("user32.dll",CharSet=CharSet.Unicode,EntryPoint="SendMessageTimeoutW")]static extern IntPtr ReadText(IntPtr h,uint m,IntPtr w,StringBuilder l,uint flags,uint timeout,out IntPtr r);
 [DllImport("kernel32.dll",SetLastError=true)]static extern IntPtr OpenProcess(uint rights,bool inherit,int pid);
 [DllImport("kernel32.dll")]static extern bool CloseHandle(IntPtr h);
 [DllImport("kernel32.dll",SetLastError=true)]static extern IntPtr VirtualAllocEx(IntPtr p,IntPtr a,UIntPtr n,uint type,uint protect);
 [DllImport("kernel32.dll")]static extern bool VirtualFreeEx(IntPtr p,IntPtr a,UIntPtr n,uint type);
 [DllImport("kernel32.dll")]static extern bool WriteProcessMemory(IntPtr p,IntPtr a,byte[] b,UIntPtr n,out UIntPtr written);
 [DllImport("kernel32.dll")]static extern bool ReadProcessMemory(IntPtr p,IntPtr a,byte[] b,UIntPtr n,out UIntPtr read);
 public static IntPtr Ptr(IntPtr h,uint m,IntPtr w,IntPtr l){IntPtr r;if(h==IntPtr.Zero||SendPtr(h,m,w,l,2,3000,out r)==IntPtr.Zero)throw new Exception("MT5 WebRequest control timed out.");return r;}
 public static void Text(IntPtr h,string text){IntPtr r;if(h==IntPtr.Zero||SendText(h,12,IntPtr.Zero,text,2,3000,out r)==IntPtr.Zero)throw new Exception("MT5 URL editor timed out.");}
 public static IntPtr Window(int pid,string title){IntPtr found=IntPtr.Zero;EnumWindows((h,p)=>{uint own;GetWindowThreadProcessId(h,out own);if(own!=pid)return true;var s=new StringBuilder(256);if(title=="terminal"){GetClassName(h,s,256);if(!s.ToString().Contains("MetaTrader"))return true;}else{GetWindowText(h,s,256);if(s.ToString()!=title||!IsWindowVisible(h))return true;}found=h;return false;},IntPtr.Zero);return found;}
 public static IntPtr Control(IntPtr root,int id){IntPtr found=IntPtr.Zero;EnumChildWindows(root,(h,p)=>{if(GetDlgCtrlID(h)==id&&IsWindowVisible(h)){found=h;return false;}return true;},IntPtr.Zero);return found;}
 public static string Label(IntPtr h){var s=new StringBuilder(512);GetWindowText(h,s,512);return s.ToString().Replace("&","");}
 public static IntPtr UrlEditor(IntPtr options){IntPtr found=IntPtr.Zero;int count=0;EnumChildWindows(options,(h,p)=>{var s=new StringBuilder(256);GetClassName(h,s,256);if(IsWindowVisible(h)&&s.ToString()=="Edit"){found=h;count++;}return true;},IntPtr.Zero);return count==1?found:IntPtr.Zero;}
 public static void EditRow(IntPtr list,int index,int pid){Ptr(list,4115,(IntPtr)index,IntPtr.Zero);System.Threading.Thread.Sleep(50);var process=OpenProcess(0x38,false,pid);if(process==IntPtr.Zero)throw new Exception("Cannot access owned URL row.");IntPtr memory=IntPtr.Zero;try{memory=VirtualAllocEx(process,IntPtr.Zero,(UIntPtr)64,0x3000,4);if(memory==IntPtr.Zero)throw new Exception("Cannot allocate URL row buffer.");var rect=new byte[16];UIntPtr done;if(!WriteProcessMemory(process,memory,rect,(UIntPtr)16,out done))throw new Exception("Cannot prepare URL row buffer.");if(Ptr(list,4110,(IntPtr)index,memory)==IntPtr.Zero||!ReadProcessMemory(process,memory,rect,(UIntPtr)16,out done))throw new Exception("Cannot locate URL row.");int x=BitConverter.ToInt32(rect,0)+40,y=(BitConverter.ToInt32(rect,4)+BitConverter.ToInt32(rect,12))/2;if(x<0||y<0||x>4096||y>4096)throw new Exception("Invalid URL row coordinates.");var point=(IntPtr)(x|(y<<16));PostMessage(list,513,(IntPtr)1,point);PostMessage(list,514,IntPtr.Zero,point);PostMessage(list,515,(IntPtr)1,point);PostMessage(list,514,IntPtr.Zero,point);}finally{if(memory!=IntPtr.Zero)VirtualFreeEx(process,memory,UIntPtr.Zero,0x8000);CloseHandle(process);}}
 public static uint OptionsMenu(IntPtr h){var menu=GetMenu(h);for(int i=0;i<GetMenuItemCount(menu);i++){var s=new StringBuilder(256);GetMenuString(menu,(uint)i,s,256,1024);if(s.ToString().Replace("&","")!="Tools")continue;var sub=GetSubMenu(menu,i);for(int j=0;j<GetMenuItemCount(sub);j++){s.Clear();GetMenuString(sub,(uint)j,s,256,1024);if(s.ToString().Replace("&","").StartsWith("Options"))return GetMenuItemID(sub,j);}}return 0;}
 public static string EditorText(IntPtr edit){var text=new StringBuilder(2048);IntPtr result;if(ReadText(edit,13,(IntPtr)2048,text,2,3000,out result)==IntPtr.Zero)throw new Exception("Cannot read owned URL editor.");return text.ToString();}
 public static string[] Urls(IntPtr list,int pid,IntPtr options){
  uint own;GetWindowThreadProcessId(list,out own);if(own!=pid)throw new Exception("Wrong URL list owner.");
  int count=Ptr(list,4100,IntPtr.Zero,IntPtr.Zero).ToInt32();if(count<1||count>100)throw new Exception("Invalid URL list length.");
  var values=new List<string>();
  // MT5 paints this virtual list itself. Read its native editor instead of
  // treating the owner-drawn rows as standard list-view text.
  for(int i=0;i<count-1;i++){
   EditRow(list,i,pid);System.Threading.Thread.Sleep(100);var edit=UrlEditor(options);
   if(edit==IntPtr.Zero)throw new Exception("Cannot inspect an owned URL row.");
   values.Add(EditorText(edit));PostMessage(edit,8,list,IntPtr.Zero);System.Threading.Thread.Sleep(100);
  }
  values.Add("");return values.ToArray();
 }
}
'@
$options=[IntPtr]::Zero;$deadline=[DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
try{
 foreach($title in @('Login','Open an Account')){$window=[CornGridWebRequest]::Window($ownedPid,$title);if($window -ne [IntPtr]::Zero){[void][CornGridWebRequest]::PostMessage($window,273,[IntPtr]2,[IntPtr]::Zero)}}
 do{
  $options=[CornGridWebRequest]::Window($ownedPid,'Options')
  if($options -eq [IntPtr]::Zero){$main=[CornGridWebRequest]::Window($ownedPid,'terminal');$command=[CornGridWebRequest]::OptionsMenu($main);if($command){[void][CornGridWebRequest]::PostMessage($main,273,[IntPtr]$command,[IntPtr]::Zero)}}
  Start-Sleep -Milliseconds 250
 }while($options -eq [IntPtr]::Zero -and [DateTime]::UtcNow -lt $deadline)
 if($options -eq [IntPtr]::Zero){throw 'English MT5 Options window is unavailable.'}
 $tabs=[CornGridWebRequest]::Control($options,12320)
 # Verify the page by its exact checkbox label before making any changes.
 [void][CornGridWebRequest]::PostMessage($tabs,4912,[IntPtr]3,[IntPtr]::Zero);Start-Sleep -Milliseconds 300
 $check=[CornGridWebRequest]::Control($options,10322);$list=[CornGridWebRequest]::Control($options,10191)
 if($check -eq [IntPtr]::Zero -or [CornGridWebRequest]::Label($check) -ne 'Allow WebRequest for listed URL:' -or $list -eq [IntPtr]::Zero){throw 'Expected MT5 WebRequest settings are unavailable.'}
 if([CornGridWebRequest]::Ptr($check,240,[IntPtr]::Zero,[IntPtr]::Zero).ToInt32() -ne 1){[void][CornGridWebRequest]::PostMessage($check,245,[IntPtr]::Zero,[IntPtr]::Zero);Start-Sleep -Milliseconds 200}
 foreach($url in $request.urls){
  if([DateTime]::UtcNow -ge $deadline){throw 'MT5 WebRequest setup exceeded its deadline.'}
  $current=@([CornGridWebRequest]::Urls($list,$ownedPid,$options))
  if($current -contains $url){continue}
  $index=$current.Count-1
  if($index -lt 0 -or $current[$index] -match '^https?://'){throw 'MT5 URL insertion row is unavailable.'}
  $edit=[CornGridWebRequest]::Ptr($list,4214,[IntPtr]$index,[IntPtr]::Zero)
  if($edit -eq [IntPtr]::Zero){[CornGridWebRequest]::EditRow($list,$index,$ownedPid);Start-Sleep -Milliseconds 200;$edit=[CornGridWebRequest]::UrlEditor($options)}
  if($edit -eq [IntPtr]::Zero){throw 'MT5 URL editor is unavailable.'}
  [CornGridWebRequest]::Text($edit,$url)
  [void][CornGridWebRequest]::PostMessage($edit,8,$list,[IntPtr]::Zero)
  Start-Sleep -Milliseconds 250
  if(@([CornGridWebRequest]::Urls($list,$ownedPid,$options)) -notcontains $url){throw 'MT5 did not accept the required URL.'}
 }
 $current=@([CornGridWebRequest]::Urls($list,$ownedPid,$options))
 if(@($request.urls|Where-Object{$current -notcontains $_}).Count -or [CornGridWebRequest]::Ptr($check,240,[IntPtr]::Zero,[IntPtr]::Zero).ToInt32() -ne 1){throw 'MT5 WebRequest verification failed.'}
 [void][CornGridWebRequest]::PostMessage($options,273,[IntPtr]1,[IntPtr]::Zero)
 do{Start-Sleep -Milliseconds 200}while([CornGridWebRequest]::Window($ownedPid,'Options') -ne [IntPtr]::Zero -and [DateTime]::UtcNow -lt $deadline)
 if([CornGridWebRequest]::Window($ownedPid,'Options') -ne [IntPtr]::Zero){throw 'MT5 did not save WebRequest settings.'}
 $options=[IntPtr]::Zero
 @{ok=$true;requestId=$request.requestId;urls=@($request.urls);verifiedAt=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()} | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $ResultFile -Encoding UTF8
}catch{
 @{ok=$false;requestId=$request.requestId;error='MT5 could not configure and verify the required WebRequest URLs. Check the interactive English MT5 session.'} | ConvertTo-Json | Set-Content -LiteralPath $ResultFile -Encoding UTF8
 Write-Error $_;exit 1
}finally{if($options -ne [IntPtr]::Zero){[void][CornGridWebRequest]::PostMessage($options,273,[IntPtr]2,[IntPtr]::Zero)}}
