param(
 [Parameter(Mandatory=$true)][string]$InstanceDir,
 [Parameter(Mandatory=$true)][string]$Search,
 [Parameter(Mandatory=$true)][string]$PythonPath,
 [Parameter(Mandatory=$true)][string]$RequestId,
 [string]$ProbeTerminal='',
 [string]$WebRequestFile=''
)
$ErrorActionPreference='Stop'
$InstanceDir=[IO.Path]::GetFullPath($InstanceDir)
if((Split-Path $InstanceDir -Leaf) -notmatch '^(sbx|eatest)_[a-f0-9]{18}$'){throw 'Invalid sandbox path'}
$targetDirectory=if($ProbeTerminal){[IO.Path]::GetFullPath($ProbeTerminal)}else{$InstanceDir}
$terminal=Join-Path $targetDirectory 'terminal64.exe'
$result=Join-Path $InstanceDir 'config\broker-preflight-result.json'
$startup=Join-Path $InstanceDir 'config\broker-preflight.ini'
$seed=Join-Path $targetDirectory 'config\servers.dat'
$phase='preparing the isolated terminal'
function Stop-OwnedTerminal {
 foreach($owner in @(Get-CimInstance Win32_Process -Filter "Name='terminal64.exe'" -ErrorAction Stop|Where-Object{$_.ExecutablePath -and $_.ExecutablePath -ieq $terminal})){
  $process=Get-Process -Id $owner.ProcessId -ErrorAction SilentlyContinue
  if($process){[void]$process.CloseMainWindow();if(-not $process.WaitForExit(8000)){Stop-Process -Id $process.Id -Force}}
 }
}
function Start-OwnedTerminal([bool]$writable=$false){
 if(@(Get-CimInstance Win32_Process -Filter "Name='terminal64.exe'" -ErrorAction Stop|Where-Object{$_.ExecutablePath -and $_.ExecutablePath -ieq $terminal}).Count){throw 'Owned preflight terminal is already running'}
 $arguments=@('/portable');if(-not $writable){$arguments+=('/config:"'+$startup+'"')}
 $null=Start-Process -FilePath $terminal -ArgumentList $arguments -WorkingDirectory $targetDirectory -WindowStyle Hidden -PassThru
 Start-Sleep -Seconds 2
}
try{
 if(-not(Test-Path -LiteralPath $terminal) -or -not(Test-Path -LiteralPath $startup)){throw 'MT5 preflight files missing'}
 $text=[IO.File]::ReadAllText($startup,[Text.Encoding]::Unicode)
 $expectedServer=([regex]::Match($text,'(?m)^Server=([^\r\n]+)')).Groups[1].Value
 if(-not $expectedServer){throw 'Expected broker server missing'}
 Stop-OwnedTerminal
 $known=$false
 if(Test-Path -LiteralPath $seed){$bytes=[IO.File]::ReadAllBytes($seed);$known=[Text.Encoding]::Unicode.GetString($bytes).IndexOf($expectedServer,[StringComparison]::OrdinalIgnoreCase) -ge 0 -or [Text.Encoding]::UTF8.GetString($bytes).IndexOf($expectedServer,[StringComparison]::OrdinalIgnoreCase) -ge 0}
 Start-OwnedTerminal
 $phase='verifying broker login and reading account symbols'
 & $PythonPath (Join-Path $PSScriptRoot 'broker-probe.py') $InstanceDir $RequestId $targetDirectory|Out-Null
 if($LASTEXITCODE -ne 0 -or -not(Test-Path -LiteralPath $result)){throw 'Python MT5 verification failed'}
 $first=Get-Content -LiteralPath $result -Raw|ConvertFrom-Json
 if(-not $first.ok -and -not $known){
  Remove-Item -LiteralPath $result -Force
  $phase='discovering the requested broker server'
  & powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'discover-broker.ps1') -TerminalDirectory $targetDirectory -Search $Search -ExpectedServer $expectedServer -StartupFile $startup -TimeoutSeconds 90|Out-Null
  if($LASTEXITCODE -ne 0){throw 'Broker discovery failed'}
  $phase='verifying the discovered broker account'
  & $PythonPath (Join-Path $PSScriptRoot 'broker-probe.py') $InstanceDir $RequestId $targetDirectory|Out-Null
  if($LASTEXITCODE -ne 0 -or -not(Test-Path -LiteralPath $result)){throw 'Python MT5 verification failed'}
 }
 $verified=Get-Content -LiteralPath $result -Raw | ConvertFrom-Json
 if($verified.ok -and $WebRequestFile){
  $phase='configuring and verifying required WebRequest URLs'
  # Custom /config files are read-only in MT5. Save the URL list in the owned
  # portable terminal's writable native profile, with experts still disabled.
  Stop-OwnedTerminal
  Start-OwnedTerminal $true
  $webResult=Join-Path $InstanceDir 'config\webrequest-result.json'
  & powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'configure-webrequest.ps1') -TerminalDirectory $targetDirectory -RequestFile $WebRequestFile -ResultFile $webResult -TimeoutSeconds 90 | Out-Null
  if($LASTEXITCODE -ne 0 -or -not(Test-Path -LiteralPath $webResult)){throw 'WebRequest setup failed'}
  $web=Get-Content -LiteralPath $webResult -Raw | ConvertFrom-Json
  if(-not $web.ok -or $web.requestId -ne $RequestId){throw 'WebRequest verification failed'}
 }
 Stop-OwnedTerminal
 if($verified.ok -and $WebRequestFile){
  $common=Join-Path $targetDirectory 'config\common.ini';$bytes=[IO.File]::ReadAllBytes($common)
  $native=if($bytes.Length -ge 2 -and $bytes[0] -eq 255 -and $bytes[1] -eq 254){[Text.Encoding]::Unicode.GetString($bytes)}else{[Text.Encoding]::UTF8.GetString($bytes)}
  $section=[regex]::Match($native,'(?ims)^\[Experts\]\s*\r?\n(.*?)(?=^\[|\z)').Groups[1].Value
  $enabled=[regex]::Match($section,'(?im)^WebRequest=([^\r\n]+)').Groups[1].Value
  $urls=[regex]::Match($section,'(?im)^WebRequestUrl=([^\r\n]+)').Groups[1].Value
  if($enabled -ne '1' -or -not $urls){throw 'MT5 did not persist its WebRequest settings'}
  $settings=Join-Path $InstanceDir 'config\webrequest-settings.ini'
  [IO.File]::WriteAllText($settings,("[Experts]`r`nWebRequest=1`r`nWebRequestUrl="+$urls+"`r`n"),[Text.Encoding]::Unicode)
  $web | Add-Member -NotePropertyName settingsHash -NotePropertyValue ((Get-FileHash -LiteralPath $settings -Algorithm SHA256).Hash.ToLowerInvariant())
  $web | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $InstanceDir 'config\webrequest-verification.json') -Encoding UTF8
 }
 if($ProbeTerminal -and(Test-Path -LiteralPath $seed)){Copy-Item -LiteralPath $seed -Destination (Join-Path $InstanceDir 'config\servers.dat') -Force}
}catch{
 if(-not(Test-Path -LiteralPath $result)){
  @{ok=$false;requestId=$RequestId;error=('MT5 preflight failed while '+$phase+'. Check the English desktop terminal, broker directory and proxy configuration. EA was not started.')}|ConvertTo-Json|Set-Content -LiteralPath $result -Encoding UTF8
 }
}finally{Stop-OwnedTerminal}
