'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { lookup, brokerSearch } = require('./broker-resolution');
const crypto = require('node:crypto');

function bundledSeedDir(server, config) {
  if (!config.brokerCacheDir) return null;
  const key = crypto.createHash('sha256').update(String(server).toLowerCase()).digest('hex').slice(0, 24);
  return path.join(config.brokerCacheDir, 'bundled', key);
}

// Bundled metadata travels inside the existing signed agent release. It is
// stored separately so an update never replaces a node's learned directory.
function installBundledBrokerSeeds(config, bundle = require('./broker-seed-data')) {
  if (!config.brokerCacheDir) return { installed: 0, available: 0 };
  if (bundle?.format !== 1 || !Array.isArray(bundle.seeds) || bundle.seeds.length > 64) throw Error('Invalid broker seed bundle.');
  const seen = new Set();
  const seeds = bundle.seeds.map(seed => {
    if (!seed || typeof seed.server !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9 ._-]{0,127}$/.test(seed.server) ||
        seen.has(seed.server.toLowerCase()) || !Number.isSafeInteger(seed.bytes) || seed.bytes < 1 || seed.bytes > 512 * 1024 ||
        !['account_preflight', 'terminal_profile'].includes(seed.verification || 'account_preflight') ||
        ((seed.verification || 'account_preflight') === 'account_preflight' ? !Number.isSafeInteger(seed.verifiedAt) || seed.verifiedAt < 1 : seed.verifiedAt !== null) ||
        typeof seed.data !== 'string' || seed.data.length > 700000 ||
        !/^[a-f0-9]{64}$/.test(seed.sha256)) throw Error('Invalid broker seed record.');
    seen.add(seed.server.toLowerCase());
    const bytes = Buffer.from(seed.data, 'base64');
    if (bytes.toString('base64') !== seed.data || bytes.length !== seed.bytes ||
        crypto.createHash('sha256').update(bytes).digest('hex') !== seed.sha256) throw Error('Broker seed integrity check failed.');
    return { ...seed, bytes };
  });
  let installed = 0;
  for (const seed of seeds) {
    const directory = path.join(bundledSeedDir(seed.server, config), 'config');
    // Reject redirected existing ancestors before creating the seed directory.
    for (let ancestor = directory; ; ancestor = path.dirname(ancestor)) {
      if (fs.existsSync(ancestor) && fs.lstatSync(ancestor).isSymbolicLink()) throw Error('Unsafe broker seed directory.');
      if (path.dirname(ancestor) === ancestor) break;
    }
    fs.mkdirSync(directory, { recursive: true });
    const resolved = path.resolve(directory), real = fs.realpathSync(directory);
    if ((process.platform === 'win32' ? real.toLowerCase() !== resolved.toLowerCase() : real !== resolved)) throw Error('Unsafe broker seed directory.');
    const target = path.join(directory, 'servers.dat');
    if (fs.existsSync(target)) {
      if (fs.lstatSync(target).isSymbolicLink() || !fs.statSync(target).isFile()) throw Error('Unsafe broker seed file.');
      if (crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex') === seed.sha256) continue;
    }
    const temporary = target + '.' + crypto.randomUUID() + '.tmp';
    try {
      fs.writeFileSync(temporary, seed.bytes, { flag: 'wx', mode: 0o600 });
      fs.renameSync(temporary, target);
    } finally { fs.rmSync(temporary, { force: true }); }
    installed++;
  }
  return { installed, available: seeds.length };
}

function cacheDir(server, config) {
  if (!config.brokerCacheDir) return null;
  const key = require('node:crypto').createHash('sha256').update(brokerSearch(server).toLowerCase()).digest('hex').slice(0, 24);
  return path.join(config.brokerCacheDir, key);
}

function copyBrokerServerCache(dir, server, config) {
  const sourceDir = [lookup(config.brokerServerDataDirs, server), cacheDir(server, config), bundledSeedDir(server, config)]
    .find(directory => directory && fs.existsSync(path.join(directory, 'config', 'servers.dat')));
  if (!sourceDir) return false;
  const source = path.join(sourceDir, 'config', 'servers.dat');
  // A missing/stale cache must fall back to discovery, not prevent a new login.
  if (!fs.existsSync(source)) return false;
  const target = path.join(dir, 'config', 'servers.dat');
  if (path.resolve(source) === path.resolve(target)) return true;
  fs.mkdirSync(path.dirname(target), { recursive: true });
  if (fs.existsSync(target) && !fs.existsSync(target + '.before-broker-repair')) {
    fs.copyFileSync(target, target + '.before-broker-repair');
  }
  // Only the broker directory is shared. Never import account databases or credentials.
  fs.copyFileSync(source, target);
  return true;
}

function saveBrokerServerCache(dir, server, config) {
  const targetDir = cacheDir(server, config);
  const source = path.join(dir, 'config', 'servers.dat');
  if (!targetDir || !fs.existsSync(source)) return false;
  fs.mkdirSync(path.join(targetDir, 'config'), { recursive: true });
  const target = path.join(targetDir, 'config', 'servers.dat');
  const temporary = target + '.' + require('node:crypto').randomUUID() + '.tmp';
  fs.copyFileSync(source, temporary);
  fs.renameSync(temporary, target);
  return true;
}
module.exports = { copyBrokerServerCache, saveBrokerServerCache, installBundledBrokerSeeds };
