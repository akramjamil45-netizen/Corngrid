'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const REQUIRED_URLS = Object.freeze([
  'https://corngrid.com',
  'https://control.corngrid.com/text.txt',
  'https://nfs.faireconomy.media'
]);

function readEntries(file) {
  const bytes = fs.readFileSync(file);
  const text = bytes.toString(bytes[0] === 255 && bytes[1] === 254 ? 'utf16le' : 'utf8').replace(/^\uFEFF/, '');
  let section = ''; const entries = {};
  for (const line of text.split(/\r?\n/)) {
    const header = line.trim().match(/^\[([^\]]+)\]$/);
    if (header) { section = header[1].toLowerCase(); continue; }
    const entry = line.match(/^\s*(WebRequest|WebRequestUrl)\s*=(.*)$/i);
    if (section !== 'experts' || !entry) continue;
    const key = entry[1].toLowerCase() === 'webrequest' ? 'WebRequest' : 'WebRequestUrl';
    if (entries[key] !== undefined) throw Error('Duplicate WebRequest configuration.');
    entries[key] = entry[2];
  }
  if (entries.WebRequest !== '1' || !entries.WebRequestUrl) throw Error('WebRequest is disabled or its native URL list is missing.');
  return entries;
}

function readVerifiedSettings(dir, requestId) {
  const file = path.join(dir, 'config/webrequest-settings.ini');
  const receiptFile = path.join(dir, 'config/webrequest-verification.json');
  if (!fs.existsSync(file) || !fs.existsSync(receiptFile)) return null;
  try {
    const receipt = JSON.parse(fs.readFileSync(receiptFile, 'utf8').replace(/^\uFEFF/, ''));
    if (receipt.ok !== true || (requestId && receipt.requestId !== requestId) || !Number.isSafeInteger(receipt.verifiedAt) || receipt.verifiedAt < 1 ||
        !Array.isArray(receipt.urls) || REQUIRED_URLS.some(url => !receipt.urls.includes(url)) ||
        receipt.settingsHash !== crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')) return null;
    return readEntries(file);
  } catch (_) { return null; }
}

function writeRequest(dir, requestId) {
  const config = path.join(dir, 'config'); fs.mkdirSync(config, { recursive: true });
  // A failed new preflight cannot reuse an older URL verification receipt.
  for (const name of ['webrequest-settings.ini', 'webrequest-verification.json', 'webrequest-result.json']) fs.rmSync(path.join(config, name), { force: true });
  const file = path.join(config, 'webrequest-request.json');
  fs.writeFileSync(file, JSON.stringify({ requestId, urls: REQUIRED_URLS }), { mode: 0o600 });
  return file;
}

module.exports = { REQUIRED_URLS, readEntries, readVerifiedSettings, writeRequest };
