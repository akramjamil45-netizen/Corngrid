# Broker metadata distribution

Agent 1.4.3 introduced broker directory seeds in the existing signed auto-update
release and in both Windows and Linux installation packages. These are bootstrap
metadata, not account authorizations or a universal catalog of MT5 brokers.

The 1.4.4 bundle contains these exact servers:

- `Headway-Demo`
- `JustMarkets-Demo6`
- `LiteFinance-MT5-Demo`
- `RoboForex-Pro`
- `XMGlobal-MT5 10`

Headway, JustMarkets, LiteFinance and XM were captured from Windows sandbox
profiles with successful account-preflight receipts. RoboForex-Pro was captured
from an existing RoboForex MT5 profile; it is marked `terminal_profile`, with no
claimed login verification time. Its metadata is a bootstrap seed, not evidence
of successful login on a target node. Other broker/server names continue using
local caches, configured profiles or Windows discovery.

## Node behavior

At agent startup, the complete bundle is checked for valid server names, bounded
sizes, unique names, canonical Base64 and SHA-256 hashes before installation.
The agent writes only `servers.dat` under a separate `bundled` directory inside
`brokerCacheDir`. Existing learned caches and running terminals are preserved.
Updates replace only bundled seed copies when their content changes.

Deployment selects metadata in this order:

1. An existing administrator-configured `brokerServerDataDirs` profile.
2. The node's learned broker cache.
3. A bundled seed for the exact requested server, matched without case sensitivity.
4. Windows broker discovery if no suitable metadata is present or login requires it.

A missing configured profile falls through to the other sources. A seed for a
demo server does not imply that a live server from the same company is supported.
Account number, exact server, connection, trading permissions and account symbols
must still pass broker preflight before the EA starts. A successful login can
refresh the node's learned cache; node caches are not uploaded automatically.

Linux/Wine can use the same bundled seeds. Brokers without a suitable local or
bundled seed still require an administrator-prepared `servers.dat`; Linux has no
native Windows broker-directory discovery. Wine, Windows Python and MT5 runtime
requirements still apply. This release does not prove every broker works on Linux.

## Build or refresh the bundle

Use terminal directories with a successful `config/broker-resolution.json`
receipt. The directory must also contain `config/servers.dat`. Create a private
operator input outside Git:

```json
{"directories":["C:/path/to/verified/terminal"]}
```

From `Corngrid-web`:

```powershell
node scripts/build-broker-seeds.js C:/private/broker-seed-input.json
```

For an existing standalone terminal without a preflight receipt, add its data
directory under `profiles` instead of `directories` in the operator input.
The builder reads only `[Common] Server` from that profile's `common.ini` and
labels it `terminal_profile` with `verifiedAt: null`. It never labels such a
profile as a verified login. Both input lists are optional; at least one source
is required in total.

The builder reads the successful server name and verification time from normal
receipts, and copies only `servers.dat` bytes. It excludes account numbers,
passwords, `accounts.dat`, `common.ini` contents, startup files, tokens and source paths.
Review the builder's server names, capture/verification dates, hashes and sizes.
Do not label imported metadata as verified on every target VPS: each deployment
still verifies its own account connection.

The generated `agent/broker-seed-data.js` is covered by the release signature and
file hashes. Increment the agent version, rebuild `RELEASE.json` and both
installation packages, run broker/update tests, and publish through the normal
signed node channel. Do not transfer metadata by replacing a live terminal's
configuration directory. New brokers require another reviewed bundle or normal
Windows discovery; metadata can become stale as brokers change infrastructure.

## Verify rollout

Node logs report `Broker metadata ready: N bundled server(s), M installed.`
`M = 0` on a later startup means the same checked metadata was already installed.
Check this log together with the node's active agent version. It confirms seed
installation, not a login test for all listed brokers. A demo deployment remains
the end-to-end acceptance check for a particular broker/account/node combination.
